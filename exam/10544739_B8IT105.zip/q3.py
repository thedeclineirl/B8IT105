# ##################################################### #
# Student Name:   Thomas Higgins
# Student Number: 10544739
# Course title:   Programming for Big Data 
# Exam Date:      02/06/2020
# ##################################################### #

#Q3


Bob = Employee('Bob',10000)
Bob.displayEmployee()
Bob.salary_increase(10)
Bob.displayEmployee()
